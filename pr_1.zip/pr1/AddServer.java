import java.rmi.*;
import java.rmi.Naming;

public class AddServer{
  public static void main(String args[]){
    try{
      AddServerImpl addServerImpl = new AddServerImpl();
      // this calls the constructor at Serverimpl.
      
      // now we will register this object in rmi registry
      Naming.rebind("AddServer", addServerImpl);
      System.out.println("Server is running....");
      
      
    }catch(Exception e){
      System.out.println("Exception Occurred At Server!" + e.getMessage());
    }
  }
}
