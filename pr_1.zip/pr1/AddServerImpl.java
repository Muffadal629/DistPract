import java.rmi.*;
import java.rmi.RemoteException;
// import java.rm.server.*
// OR
import java.rmi.server.UnicastRemoteObject;

public class AddServerImpl extends UnicastRemoteObject implements AddServerIntf{
  public AddServerImpl() throws RemoteException{
  super();
  }
  public double addition(double num1, double num2) throws RemoteException{
    return num1 + num2;
  }
  
  
  public double subtraction(double num1, double num2) throws RemoteException{
    return num1 - num2;
  }
  
  
  public double multiplication(double num1, double num2) throws RemoteException{
    return num1 * num2;
  }
  
  
  public double division(double num1, double num2) throws RemoteException{
    if(num2 != 0){
      return num1 / num2;
    }
    else{
      System.out.println("Cannot Divide A Number by Zero.");
      return 0;
    }
    
    
  }
  }
  
  
