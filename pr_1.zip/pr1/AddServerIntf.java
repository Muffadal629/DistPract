import java.rmi.*;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface AddServerIntf extends Remote{
    // Syntax for method declaration: access_specifier return_type method_name(arguments..){return value}
    
    public double addition(double num1, double num2) throws RemoteException;
    public double subtraction(double num1, double num2) throws RemoteException;
    public double multiplication(double num1, double num2) throws RemoteException;
    public double division(double num1, double num2) throws RemoteException;
}
