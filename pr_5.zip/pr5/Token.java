import java.util.*;

public class Token{
    public static void main(String[] args){
      Scanner sc = new Scanner(System.in);
      
      System.out.println("Enter Number of Nodes You Want In The Ring :");
      int n = sc.nextInt();
      
      // Display the ring
      System.out.println("\nRing Formed is as Below :");
      for(int i = 0; i<n; i++){
        System.out.print(i + " ");
      }
      System.out.println("0\n"); // to show circular ring
      // n = 5
      // 0 1 2 3 4 0
      
      
      int choice = 1;
      int token = 0;
      do{
        System.out.println("Enter Sender (0 to "+ (n-1) +"): ");
        int sender = sc.nextInt();
        
        System.out.println("Enter Receiver (0 to "+ (n-1) +"): ");
        int receiver = sc.nextInt();
        
        //Input validation
        if(sender >=n || receiver >=n || sender <0 || receiver <0){
          System.out.println("Invalid Sender or Receiver! Please enter values between 0 and " + (n-1)+"\n");
          continue;
        }
        if(sender == receiver){
          System.out.println("Invalid Sender and Receiver cannot be the same!\n");
          continue;
        }
        
        
        
        System.out.println("Enter Data To Sent: ");
        int data = sc.nextInt();
        
        
        System.out.println("Token Passing: ");
        
       
        
        
        for(int i=token; i!=sender; i=(i+1)%n ){
          System.out.print(" "+i+" -> ");
        }
        System.out.println(sender);
      
        //Sender sends data
        System.out.println("Sender: "+ sender + " is Sending Data: "+ data);
        
        // Forwarding data through intermediate nodes
        for(int i=(sender + 1)%n; i!=receiver; i=(i+1)%n){
          System.out.println("Data: "+data+ " forwarded by node: "+i);
        }
        
        // Receiver gets data
        System.out.println("Receiver: "+ receiver + " received the data:"+ data+"\n");
        // Token is now with sender
        token = sender;
        
        System.out.print("Do You Want To Send Data Again? If YES ENTER 1, If NO ENTER 0: ");
        choice = sc.nextInt();
        System.out.println();
        }while(choice == 1);
        
        sc.close();
        System.out.println("Program ended.");
    }
}
