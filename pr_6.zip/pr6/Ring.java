import java.util.*;

public class Ring {
    static class Process {
        int id;
        boolean active;

        Process(int id) {
            this.id = id;
            this.active = true;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Process> processes = new ArrayList<>();

        System.out.print("Enter the number of processes: ");
        int n = scanner.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.print("Enter the ID of process " + (i + 1) + ": ");
            int id = scanner.nextInt();
            processes.add(new Process(id));
        }

        while (true) {
            System.out.println("\n1. Bring process down");
            System.out.println("2. Bring process up");
            System.out.println("3. Initiate election");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter process ID to bring down: ");
                    int id = scanner.nextInt();
                    setProcessState(processes, id, false);
                }
                case 2 -> {
                    System.out.print("Enter process ID to bring up: ");
                    int id = scanner.nextInt();
                    setProcessState(processes, id, true);
                }
                case 3 -> {
                    System.out.print("Enter process ID to initiate election: ");
                    int initiatorId = scanner.nextInt();
                    initiateElection(processes, initiatorId);
                }
                case 4 -> {
                    System.out.println("Exiting.");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    static void setProcessState(List<Process> processes, int id, boolean state) {
        for (Process p : processes) {
            if (p.id == id) {
                p.active = state;
                System.out.println("Process " + id + " is now " + (state ? "UP" : "DOWN"));
                return;
            }
        }
        System.out.println("Process ID not found.");
    }

    static void initiateElection(List<Process> processes, int initiatorId) {
        int n = processes.size();
        int initiatorIndex = findProcessIndex(processes, initiatorId);

        if (initiatorIndex == -1 || !processes.get(initiatorIndex).active) {
            System.out.println("Initiator process not found or is DOWN.");
            return;
        }

        System.out.println("Election initiated by Process " + initiatorId);
        int index = (initiatorIndex + 1) % n;
        int maxId = processes.get(initiatorIndex).id;

        // Send election message around the ring
        while (index != initiatorIndex) {
            Process p = processes.get(index);
            if (p.active) {
                System.out.println("Message passed to Process " + p.id);
                if (p.id > maxId) {
                    maxId = p.id;
                }
            }
            index = (index + 1) % n;
        }

        System.out.println("Process " + maxId + " becomes the new coordinator.");
    }

    static int findProcessIndex(List<Process> processes, int id) {
        for (int i = 0; i < processes.size(); i++) {
            if (processes.get(i).id == id) return i;
        }
        return -1;
    }
}

