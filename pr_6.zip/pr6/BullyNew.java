import java.util.Scanner;

public class BullyNew {

    static boolean[] state = new boolean[5];  // Tracks if each process is UP or DOWN
    static int coordinator = 4; // Initially, process P5 (index 4) is coordinator

    public static void processUp(int processID) {
        if (state[processID]) {
            System.out.println("Process P" + (processID + 1) + " is already up.");
        } else {
            state[processID] = true;
            System.out.println("Process P" + (processID + 1) + " is up.");
            if (processID > coordinator || !state[coordinator]) {
                initiateElection(processID);
            }
        }
    }

    public static void processDown(int processID) {
        if (!state[processID]) {
            System.out.println("Process P" + (processID + 1) + " is already down.");
        } else {
            state[processID] = false;
            System.out.println("Process P" + (processID + 1) + " is down.");
            if (processID == coordinator) {
                System.out.println("Coordinator (P" + (processID + 1) + ") is down.");
                int newInitiator = findHighestAlive();
                if (newInitiator == -1) {
                    System.out.println("No alive processes. Election cannot be held.");
                } else {
                    initiateElection(newInitiator);
                }
            }
        }
    }

    public static void sendMessage(int processID) {
        if (!state[processID]) {
            System.out.println("Process P" + (processID + 1) + " is down.");
        } else {
            if (state[coordinator]) {
                System.out.println("Process P" + (processID + 1) + " sends a message to Coordinator P" + (coordinator + 1));
            } else {
                System.out.println("Coordinator (P" + (coordinator + 1) + ") is down. Initiating election...");
                int newInitiator = findHighestAlive();
                if (newInitiator == -1) {
                    System.out.println("No alive processes. Election cannot be held.");
                } else {
                    initiateElection(newInitiator);
                }
            }
        }
    }

    public static void initiateElection(int initiator) {
        if (initiator < 0 || initiator >= state.length || !state[initiator]) {
            System.out.println("Invalid initiator or process is down.");
            return;
        }

        System.out.println("Election initiated by Process P" + (initiator + 1));
        boolean foundHigher = false;

        for (int i = initiator + 1; i < 5; i++) {
            if (state[i]) {
                System.out.println("Election message sent from P" + (initiator + 1) + " to P" + (i + 1));
                foundHigher = true;
            }
        }

        if (!foundHigher) {
            coordinator = initiator;
            broadcastCoordinator(coordinator);
        }
    }

    public static void broadcastCoordinator(int newCoordinator) {
        System.out.println("Process P" + (newCoordinator + 1) + " becomes the new coordinator.");
        for (int i = 0; i < 5; i++) {
            if (state[i] && i != newCoordinator) {
                System.out.println("Coordinator message sent to P" + (i + 1));
            }
        }
    }

    public static int findHighestAlive() {
        for (int i = 4; i >= 0; i--) {
            if (state[i]) return i;
        }
        return -1; // No alive process found
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 5; i++) state[i] = true;  // Initially, all processes are UP

        System.out.println("Initial State: All 5 processes are UP. Coordinator is P5.");

        int choice;
        do {
            System.out.println("\n1. Bring a process UP");
            System.out.println("2. Bring a process DOWN");
            System.out.println("3. Send message from process");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter process number (1–5) to UP: ");
                    int p = sc.nextInt();
                    if (p >= 1 && p <= 5) processUp(p - 1);
                    else System.out.println("Invalid process number.");
                }
                case 2 -> {
                    System.out.print("Enter process number (1–5) to DOWN: ");
                    int p = sc.nextInt();
                    if (p >= 1 && p <= 5) processDown(p - 1);
                    else System.out.println("Invalid process number.");
                }
                case 3 -> {
                    System.out.print("Enter process number (1–5) to send message: ");
                    int p = sc.nextInt();
                    if (p >= 1 && p <= 5) sendMessage(p - 1);
                    else System.out.println("Invalid process number.");
                }
                case 4 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice.");
            }

        } while (choice != 4);
        sc.close();
    }
}

